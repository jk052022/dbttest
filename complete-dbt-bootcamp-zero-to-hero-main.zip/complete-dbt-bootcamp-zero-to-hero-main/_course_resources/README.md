# Class Resources

This folder contains additional resources for the course. You don't need to have this folder cloned to your own computer in order to `dbt run` this project.

* [Code and additional resources for each section in the course compiled into a single Markdown document](course-resources.md)

